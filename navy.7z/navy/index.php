<?php

$someVar = "Hi!";
echo "$someVar" . " everybody!";
