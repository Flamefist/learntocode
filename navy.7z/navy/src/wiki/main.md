# Схема таблицы в БД (json)

Таблица 'project'

|  id  |  title  |  owner_name  | phone | ? |
| - | - | - | - | - |  
| 0 |  | | | |  
|

Таблица 'aeg_name'

| id | name | manufacturer | img |
| - | - | - |  
| 1 | АК-105 | CYMA | ../img/AK-105(CM040D).jpg | 
